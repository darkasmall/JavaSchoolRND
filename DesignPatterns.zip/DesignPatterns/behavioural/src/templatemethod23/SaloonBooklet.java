package templatemethod23;

/*
 *  Java Design Pattern Essentials
 *  Copyright 2010, Ability First Limited
 *
 *  This source code is provided to accompany the book and is provided AS-IS without warranty of any kind.
 *  It is intended for educational and illustrative purposes only, and may not be re-published
 *  without the express written permission of the publisher.
 */

public class SaloonBooklet extends AbstractBookletPrinter {

    protected int getPageCount() {
        return 10;
    }

    protected void printFrontCover() {
        System.out.println("Printing front cover for Saloon car booklet");
    }

    protected void printTableOfContents() {
        System.out.println("Printing table of contents for Saloon car booklet");
    }

    protected void printPage(int pageNumber) {
        System.out.println("Printing page " + pageNumber + " for Saloon car booklet");
    }

    protected void printIndex() {
        System.out.println("Printing index for Saloon car booklet");
    }

    protected void printBackCover() {
        System.out.println("Printing back cover for Saloon car booklet");
    }


}
